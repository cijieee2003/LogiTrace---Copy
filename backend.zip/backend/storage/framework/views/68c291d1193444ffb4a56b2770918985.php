<?php echo e($slot); ?>

<?php /**PATH C:\Users\jingv\OneDrive\Desktop\LogiTrace - Copy\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>