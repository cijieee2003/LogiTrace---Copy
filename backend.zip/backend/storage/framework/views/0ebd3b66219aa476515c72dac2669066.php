<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\jingv\OneDrive\Desktop\LogiTrace - Copy\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>