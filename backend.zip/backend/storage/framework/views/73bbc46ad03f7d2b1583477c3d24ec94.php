<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\LogiTrace - Copy\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>